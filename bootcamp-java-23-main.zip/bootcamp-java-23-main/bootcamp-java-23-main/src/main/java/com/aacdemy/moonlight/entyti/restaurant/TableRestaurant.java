package com.aacdemy.moonlight.entyti.restaurant;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "restaurant_table")
public class TableRestaurant {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id",nullable = false)
    private Long id;

    @Column(name = "zone",nullable = false)
    private TableZone zone;

    @Column(name = "is_smoking",nullable = false)
    private boolean isSmoking;

    @Column(name = "seats",nullable = false)
    private int seats;

    @Column(name = "table_number",nullable = false)
    private int tableNumber;

}
