package com.aacdemy.moonlight.entyti.restaurant;

public enum TableZone {
    BAR,
    SALON,
    TERRACE
}
