package com.aacdemy.moonlight.entyti.restaurant;

import jakarta.persistence.*;
import lombok.*;
import org.springframework.security.core.userdetails.User;

import java.time.LocalDate;
import java.time.LocalDateTime;
@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "reservation")

public class TableReservation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "date",nullable = false)
    private LocalDate date;

    @Column(name = "time",nullable = false)
    private LocalDateTime hour;

    @ManyToMany
    @JoinColumn(name = "table_id",nullable = false)
    private Table table;

    @ManyToOne
    @JoinColumn(name = "user_id",nullable = false)
    private User user;

    @Column(name = "price",nullable = false)
    private double price;

}
